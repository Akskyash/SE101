#include <iostream>
using namespace std;
int main()
{
    int sum=0;
    int i;
    for(i=100;i>=1;i--)
    {
    sum=sum+i;
    cout<<i<<endl;
    //cout<<"sum"<<sum<<endl;
    }
    cout<<"sum"<<sum<<endl;

}
/*i amgoing i found a  place that is really far away from fromhere .but iamscjhd*/
