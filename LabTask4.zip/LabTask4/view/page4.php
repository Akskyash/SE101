<?php

session_start();
echo "<h2>".$_SESSION["fname"]."</h2>"
?>