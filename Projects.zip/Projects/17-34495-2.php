<html>

	<body>
	
	<?php
		
		$xml = simplexml_load_file(index.xml);
		
		$err_username="";
		$username="";
		
		$err_password="";
		$password="";
		
		$admin="abc";
		$admin_pass="123";
		
		$r_user="xyz";
		$r_user_pass="789";
		
		if(isset($_POST['submit']))
		{
			
			if (empty($_POST['username']))
			{
				$err_username="*Usename Required";				
			}
			else
			{
				$username=$_POST['username'];								
			}
				
			if (empty($_POST['password']))
			{
				$err_password="*Password Required";
			}
			else
			{
				$password=$_POST['password'];
			}					
			
			if($username==$admin and $password==$admin_pass)
			{
				header("Location:Homepage.php");
			}
			
			if($username==$r_user and $password==$r_user_pass)
			{
				header("Location:RHomepage.php");
			}
			
			
			if($username==$admin and $password!=$admin_pass or $username==$r_user and $password!=$r_user_pass)
			{
				echo "Wrong Password.";
				$password = "";
			}
			elseif(($username!=$admin and $password==$admin_pass or $username!=$r_user and $password==$r_user_pass))
			{
				echo "Wrong Username";
				$username="";
			}
			else
			{
				echo "Wrong User & Password.";
				$username = "";
				$password = "";
			}
			
			

			
		}	
		
	?>
	
	
		<form method="post" action="">
		
		<table align="center">
		
			<tr>
				<td>Username</td>
				<td>	<input type="text" name="username" value="<?php echo $username;?>">
				<br><span style="color:red"><?php echo $err_username;?></span>		</td>
			</tr>
			
			<tr>
				<td>Password</td>
				<td>	<input type="password" name="password" value="<?php echo $password;?>">
				<br><span style="color:red"><?php echo $err_password;?></span>		</td>
			</tr>
			
			<tr>
				<td><input type="submit" value="Submit" name="submit"></td>
			</tr>
		
		</table>
		
		</form>
	
	</body>

</html>