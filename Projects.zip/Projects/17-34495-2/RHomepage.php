<html>
	<head>
		<title>Homepage</title>
	</head>
	<body>
	<?php
		if(isset($_POST['submit']))
		{
			header("Location:17-34495-2.php");
		}
	?>
	
	<form action="" method="post">
		<h2>Welcome To R_User Homepage</h2>
		<input type="submit" value="Logout" name="submit">
	</form>
		
	</body>
</html>